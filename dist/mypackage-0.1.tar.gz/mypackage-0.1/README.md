# mypackage
This library was created as an example of how to publish your own python packages

## Building this package locally
'python setup.py sdist'

## Installing this package from Github
'pip install git+https://github.com/RLSwanepoel/mypackage.git'

## Upgrading this package from Github
'pip install --upgrade git+https://github.com/RLSwanepoel/mypackage.git'
